﻿using ClosedXML.Excel;
using Application.Interfaces;
using Application.ViewModels;
using Domain.Filter;
using Infra.CrossCutting.IoC.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Services.Api.Controllers
{
    [Route("api-clientes")]
    public class ClientesController : ControllerBase
    {
        private readonly IClientesAppService _appService;
        private readonly ILogger<ClientesController> _logger;

        public ClientesController(IClientesAppService apoliceAppService, ILogger<ClientesController> logger)
        {
            _appService = apoliceAppService;
            _logger = logger;
        }

        [HttpGet("clientes-pf")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        public async Task<IActionResult> GetClientesPF(ClientesPFFilter dados)
        {
            Console.WriteLine(" Recebendo requisição Clientes PF");

            try
            {
                var result = await _appService.GetClientesPF(dados);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest("Informações não encontradas");
            }
        }

        [HttpGet("clientes-pf-reports")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        [ProducesResponseType(typeof(FileContentResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), 400)]
        public async Task<IActionResult> ClientesPFReports(ClientesPFFilter dados)
        {
            try
            {
                var fileName = $"Clientes_PF_{DateTime.Now.ToString("yyyyMMdd_HHmmss")}.xlsx";
                Console.WriteLine(" Recebendo requisição Clientes PF");

                XLWorkbook wb = new XLWorkbook();
                wb.Worksheets.Add(await _appService.GetClientesPFReports(dados), "Clientes PF");
                wb.SaveAs($"files/{fileName}");

                var filePath = $"files/{fileName}"; // get file full path based on file name
                if (!System.IO.File.Exists(filePath))
                {
                    return BadRequest();
                }

                return File(await System.IO.File.ReadAllBytesAsync(filePath), "application/octet-stream", fileName);
            }
            catch (Exception ex)
            {
                return BadRequest("Informações não encontradas");
            }
        }

        [HttpGet("clientes-pj")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        public async Task<IActionResult> GetClientesPJ(ClientesPJFilter dados)
        {
            Console.WriteLine(" Recebendo requisição Clientes PJ");

            try
            {
                var result = await _appService.GetClientesPJ(dados);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest("Informações não encontradas");
            }
        }

        [HttpGet("clientes-pj-reports")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        [ProducesResponseType(typeof(FileContentResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), 400)]
        public async Task<IActionResult> ClientesPJReports(ClientesPJFilter dados)
        {
            try
            {
                var fileName = $"Clientes_PJ_{DateTime.Now.ToString("yyyyMMdd_HHmmss")}.xlsx";
                Console.WriteLine(" Recebendo requisição Clientes PJ");

                XLWorkbook wb = new XLWorkbook();
                wb.Worksheets.Add(await _appService.GetClientesPJReports(dados), "Clientes PJ");
                wb.SaveAs($"files/{fileName}");

                var filePath = $"files/{fileName}"; // get file full path based on file name
                if (!System.IO.File.Exists(filePath))
                {
                    return BadRequest();
                }

                return File(await System.IO.File.ReadAllBytesAsync(filePath), "application/octet-stream", fileName);
            }
            catch (Exception ex)
            {
                return BadRequest("Informações não encontradas");
            }
        }

        [HttpPost("clientes-pf-incluir")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        public async Task<IActionResult> IncluirClientesPF([FromBody] ClientesPFInsert dados)
        {
            try
            {
                string mensagem = "Cliente Pessoa Física incluido com sucesso";

                if (dados == null)
                {
                    return BadRequest("Dados precisam ser informados!");
                }

                if (string.IsNullOrEmpty(dados.CPF))
                {
                    return BadRequest("CPF precisa ser informado !");
                }

                if (dados.CPF.Length != 11)
                {
                    return BadRequest("CPF precisa ter 11 dígitos !");
                }
                try
                {
                    long numCpf = Convert.ToInt64(dados.CPF);
                }
                catch 
                {
                    return BadRequest("CPF precisa conter somente números");
                }

                if (string.IsNullOrEmpty(dados.Nome))
                {
                    return BadRequest("Nome precisa ser informado !");
                }

                if (!string.IsNullOrEmpty(dados.Sexo))
                {
                    if ((dados.Sexo.ToUpper().Substring(0,1) != "M") && (dados.Sexo.ToUpper().Substring(0, 1) != "F") && (dados.Sexo.ToUpper().Substring(0, 1) != "O"))
                    {
                        return BadRequest("Informe Sexo sendo M=Masculino, F=Feminino ou O=Outros");
                    }
                }

                if (await _appService.AddClientesPF(dados) == false)
                {
                    return BadRequest("Erro ao incluir a Cliente Pessoa Física");
                }

                return Ok(mensagem);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir Cliente Pessoa Física");
            }
        }

        [HttpPost("clientes-pf-excluir")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        public async Task<IActionResult> ClientesPFExcluir([FromBody] ClientesPFDelete dados)
        {
            try
            {
                string mensagem = "Cliente Pessoa Física excluído com sucesso";

                if (dados == null)
                {
                    return BadRequest("Id precisa ser informado");
                }

                if (dados.IdClientesPF <= 0)
                {
                    return BadRequest("Id precisa ser informado");
                }

                var filtros = new ClientesPFFilter();
                filtros.IdClientesPF = dados.IdClientesPF;
                var result = await _appService.GetClientesPF(filtros);

                if (result.QtdeLinhas == 0)
                {
                    return BadRequest("Cliente não encontrado !");
                }

                if (await _appService.DeleteClientesPF(dados) == false)
                {
                    return BadRequest("Erro ao excluir os dados do Cliente Pessoa Física");
                }

                return Ok(mensagem);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir os dados do Cliente Pessoa Física");
            }
        }
        [HttpPost("clientes-pj-incluir")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        public async Task<IActionResult> IncluirClientesPJ([FromBody] ClientesPJInsert dados)
        {
            try
            {
                string mensagem = "Cliente Pessoa Jurídica incluido com sucesso";

                if (dados == null)
                {
                    return BadRequest("Dados precisam ser informados!");
                }

                if (string.IsNullOrEmpty(dados.CNPJ))
                {
                    return BadRequest("CNPJ precisa ser informado !");
                }

                if (dados.CNPJ.Length != 14)
                {
                    return BadRequest("CNPJ precisa ter 14 dígitos !");
                }
                try
                {
                    long numCnpj = Convert.ToInt64(dados.CNPJ);
                }
                catch
                {
                    return BadRequest("CNPJ precisa conter somente números");
                }

                if (string.IsNullOrEmpty(dados.RazaoSocial))
                {
                    return BadRequest("Razão Social precisa ser informada !");
                }

                if (await _appService.AddClientesPJ(dados) == false)
                {
                    return BadRequest("Erro ao incluir a Cliente Pessoa Jurídica");
                }

                return Ok(mensagem);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir Cliente Pessoa Jurídica");
            }
        }

        [HttpPost("clientes-pj-excluir")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        public async Task<IActionResult> ClientesPJExcluir([FromBody] ClientesPJDelete dados)
        {
            try
            {
                string mensagem = "Cliente Pessoa Jurídica excluído com sucesso";

                if (dados == null)
                {
                    return BadRequest("Id precisa ser informado");
                }

                if (dados.IdClientesPJ <= 0)
                {
                    return BadRequest("Id precisa ser informado");
                }

                var filtros = new ClientesPJFilter();
                filtros.IdClientesPJ = dados.IdClientesPJ;
                var result = await _appService.GetClientesPJ(filtros);

                if (result.QtdeLinhas == 0)
                {
                    return BadRequest("Cliente não encontrado !");
                }

                if (await _appService.DeleteClientesPJ(dados) == false)
                {
                    return BadRequest("Erro ao excluir os dados do Cliente Pessoa Jurídica");
                }

                return Ok(mensagem);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir os dados do Cliente Pessoa Jurídica");
            }
        }
    }
}
