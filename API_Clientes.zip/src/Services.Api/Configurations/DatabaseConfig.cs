﻿using Infra.Data.Context;
using Microsoft.EntityFrameworkCore;
using Amazon.DynamoDBv2;
using Microsoft.Extensions.Options;

namespace Services.Api.Configurations
{
    public static class DatabaseConfig
    {
        public static void AddDatabaseConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            var conn = Environment.GetEnvironmentVariable("CONNECTION_STRING");

            if (services == null) throw new ArgumentNullException(nameof(services));

            services.AddDbContext<DBContext>(options =>
                options.UseSqlServer(conn));
        }
    }
}
