﻿using Domain.Filter;
using Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Domain.Interfaces
{
    public interface IClientesRepository
    {
        public Task<List<ClientesPF>> GetClientesPF(ClientesPFFilter filter);
        public Task<List<ClientesPJ>> GetClientesPJ(ClientesPJFilter filter);
        public Task<bool> AddClientesPFAsync(ClientesPF dados);
        public Task<bool> UpdateClientesPFAsync(ClientesPF dados);
        public Task<bool> DeleteClientesPFAsync(int IdClientesPF);
        public Task<bool> AddClientesPJAsync(ClientesPJ dados);
        public Task<bool> UpdateClientesPJAsync(ClientesPJ dados);
        public Task<bool> DeleteClientesPJAsync(int IdClientesPJ);
    }
}
