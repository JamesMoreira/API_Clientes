﻿using Domain.Models;
using System.Collections.Generic;

namespace Domain.Summary
{
    public class ClientesPJReportSummary
    {
        public List<ClientesPJ> Clientes { get; set; }
        public int QtdeLinhas { get; set; }
    }
}
