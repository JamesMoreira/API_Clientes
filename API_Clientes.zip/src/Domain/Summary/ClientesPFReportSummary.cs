﻿using Domain.Models;
using System.Collections.Generic;

namespace Domain.Summary
{
    public class ClientesPFReportSummary
    {
        public List<ClientesPF> Clientes { get; set; }
        public int QtdeLinhas { get; set; }
    }
}
