﻿namespace Domain.Filter
{
    public class ClientesPFFilter
    {
        public int? IdClientesPF { get; set; }
        public string CPF { get; set; }
        public string Nome { get; set; }
    }
}
