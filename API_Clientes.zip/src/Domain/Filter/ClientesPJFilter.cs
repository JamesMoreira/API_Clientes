﻿namespace Domain.Filter
{
    public class ClientesPJFilter
    {
        public int? IdClientesPJ { get; set; }
        public string CNPJ { get; set; }
        public string RazaoSocial { get; set; }
        public string NomeFantasia { get; set; }
    }
}
