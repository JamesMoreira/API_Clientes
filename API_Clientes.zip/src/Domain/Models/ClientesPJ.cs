﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Models
{
    [Table("ClientesPJ")]
    public class ClientesPJ
    {
        public int IdClientesPJ { get; set; }
        public string CNPJ { get; set; }
        public string RazaoSocial { get; set; }
        public string NomeFantasia { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }
        public string Email { get; set; }
        public DateTime DataAtualizacao { get; set; }
    }
}
