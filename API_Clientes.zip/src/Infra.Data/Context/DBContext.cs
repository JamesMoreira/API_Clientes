﻿using Domain.Models;
using FluentValidation.Results;
using Microsoft.EntityFrameworkCore;
using NetDevPack.Messaging;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Infra.Data.Repository;
using Domain.Summary;

namespace Infra.Data.Context
{
    public sealed class DBContext : IdentityDbContext<IdentityUser>
    {
        public DBContext(DbContextOptions<DBContext> options) : base(options)
        {
            ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            ChangeTracker.AutoDetectChangesEnabled = false;
        }

        public DbSet<ClientesPF> ClientesPF { get; set; }
        public DbSet<ClientesPJ> ClientesPJ { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ClientesPF>()
             .HasKey(x => x.IdClientesPF);

            modelBuilder.Entity<ClientesPJ>()
             .HasKey(x => x.IdClientesPJ);

            modelBuilder.Ignore<ValidationResult>();
            modelBuilder.Ignore<Event>();
                        
            base.OnModelCreating(modelBuilder);
        }
    }
}
