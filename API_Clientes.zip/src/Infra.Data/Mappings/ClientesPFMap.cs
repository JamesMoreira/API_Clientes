using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain.Models;

namespace Infra.Data.Mappings
{    
    public class ClientesPFMap : IEntityTypeConfiguration<ClientesPF>
    {
        public void Configure(EntityTypeBuilder<ClientesPF> builder)
        {
            builder.HasKey(x => x.IdClientesPF);
        }
    }
}
