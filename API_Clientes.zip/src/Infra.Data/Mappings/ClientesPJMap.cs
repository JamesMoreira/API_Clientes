﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain.Models;

namespace Infra.Data.Mappings
{
    public class ClientesPJMap : IEntityTypeConfiguration<ClientesPJ>
    {
        public void Configure(EntityTypeBuilder<ClientesPJ> builder)
        {
            builder.HasKey(x => x.IdClientesPJ);
        }
    }
}
