﻿using Dapper;
using Domain.Filter;
using Domain.Interfaces;
using Domain.Models;
using Domain.Summary;
using Infra.Data.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infra.Data.Repository
{
    public class ClientesRepository : IClientesRepository
    {
        protected readonly DBContext _applicationDbContext;

        public ClientesRepository(DBContext context) 
        {
            _applicationDbContext = context;
        }
        public async Task<List<ClientesPF>> GetClientesPF(ClientesPFFilter filter)
        {
            try
            {
                string aux = " Where ";

                var sql = "Select IdClientesPF, CPF, Nome, Sexo, DataNascimento, RG, Endereco, Telefone, Email, DataAtualizacao From ClientesPF (nolock)";

                if ((filter.IdClientesPF ?? 0) > 0)
                {
                    sql = sql + aux + $" IdClientesPF = {filter.IdClientesPF}";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.CPF))
                {
                    sql = sql + aux + $" CPF = '{filter.CPF.Trim()}'";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.Nome))
                {
                    sql = sql + aux + $" Nome Like '%{filter.Nome.Trim()}%'";
                    aux = " And ";
                }

                sql += $" Order by Nome Asc";

                var entity = await _applicationDbContext.ClientesPF.FromSqlRaw(sql).ToListAsync();

                return entity;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao consultar banco de dados  ", ex.Message);
                throw ex;
            }
        }
        public async Task<List<ClientesPJ>> GetClientesPJ(ClientesPJFilter filter)
        {
            try
            {
                string aux = " Where ";

                var sql = "Select IdClientesPJ, CNPJ, RazaoSocial, NomeFantasia, Endereco, Telefone, Email, DataAtualizacao From ClientesPJ (nolock)";

                if ((filter.IdClientesPJ ?? 0) > 0)
                {
                    sql = sql + aux + $" IdClientesPJ = {filter.IdClientesPJ}";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.CNPJ))
                {
                    sql = sql + aux + $" CNPJ = '{filter.CNPJ.Trim()}'";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.RazaoSocial))
                {
                    sql = sql + aux + $" RazaoSocial Like '%{filter.RazaoSocial.Trim()}%'";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.NomeFantasia))
                {
                    sql = sql + aux + $" NomeFantasia Like '%{filter.NomeFantasia.Trim()}%'";
                    aux = " And ";
                }

                sql += $" Order by RazaoSocial Asc";

                var entity = await _applicationDbContext.ClientesPJ.FromSqlRaw(sql).ToListAsync();

                return entity;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao consultar banco de dados  ", ex.Message);
                throw ex;
            }
        }
        public async Task<bool> AddClientesPFAsync(ClientesPF dados)
        {
            try
            {
                string sql = $"Insert into ClientesPF (CPF, Nome, Sexo, DataNascimento, RG, Endereco, Telefone, Email, DataAtualizacao) values (";
                sql += $"'{dados.CPF}', '{dados.Nome}', '{dados.Sexo}', '{dados.DataNascimento.ToString("yyyy-MM-dd")}', '{dados.RG}', '{dados.Endereco}', '{dados.Telefone}', '{dados.Email}', GETDATE());";
                var result = await _applicationDbContext.Database.ExecuteSqlRawAsync(sql);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao incluir Clientes Pessoa Física ", ex.Message);
                return false;
            }
        }
        public async Task<bool> UpdateClientesPFAsync(ClientesPF dados)
        {
            try
            {
                string sql = $"Update ClientesPF Set Nome = '{dados.Nome}', Sexo = '{dados.Sexo}', DataNascimento = '{dados.DataNascimento.ToString("yyyy-MM-dd")}', RG = '{dados.RG}', Endereco = '{dados.Endereco}', Telefone = '{dados.Telefone}', Email = '{dados.Email}', DataAtualizacao = GETDATE() Where IdClientesPF = {dados.IdClientesPF}";
                var result = await _applicationDbContext.Database.ExecuteSqlRawAsync(sql);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao alterar Clientes Pessoa Física ", ex.Message);
                return false;
            }
        }
        public async Task<bool> DeleteClientesPFAsync(int IdClientesPF)
        {
            try
            {
                string sql = $"Delete from ClientesPF Where IdClientesPF = {IdClientesPF};";
                var result = await _applicationDbContext.Database.ExecuteSqlRawAsync(sql);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao excluir Clientes Pessoa Física ", ex.Message);
                return false;
            }
        }
        public async Task<bool> AddClientesPJAsync(ClientesPJ dados)
        {
            try
            {
                string sql = $"Insert into ClientesPJ (CNPJ, RazaoSocial, NomeFantasia, Endereco, Telefone, Email, DataAtualizacao) values (";
                sql += $"'{dados.CNPJ}', '{dados.RazaoSocial}', '{dados.NomeFantasia}', '{dados.Endereco}', '{dados.Telefone}', '{dados.Email}', GETDATE());";
                var result = await _applicationDbContext.Database.ExecuteSqlRawAsync(sql);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao incluir Clientes Pessoa Jurídica ", ex.Message);
                return false;
            }
        }
        public async Task<bool> UpdateClientesPJAsync(ClientesPJ dados)
        {
            try
            {
                string sql = $"Update ClientesPJ Set RazaoSocial = '{dados.RazaoSocial}', NomeFantasia = '{dados.NomeFantasia}', Endereco = '{dados.Endereco}', Telefone = '{dados.Telefone}', Email = '{dados.Email}', DataAtualizacao = GETDATE() Where IdClientesPJ = {dados.IdClientesPJ}";
                var result = await _applicationDbContext.Database.ExecuteSqlRawAsync(sql);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao alterar Clientes Pessoa Jurídica ", ex.Message);
                return false;
            }
        }
        public async Task<bool> DeleteClientesPJAsync(int IdClientesPJ)
        {
            try
            {
                string sql = $"Delete from ClientesPJ Where IdClientesPJ = {IdClientesPJ};";
                var result = await _applicationDbContext.Database.ExecuteSqlRawAsync(sql);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao excluir Clientes Pessoa Jurídica ", ex.Message);
                return false;
            }
        }
    }
}
