﻿using System;
using System.Threading.Tasks;
using Application.Interfaces;
using Microsoft.Extensions.Logging;
using Application.ViewModels;
using Domain.Filter;
using Domain.Interfaces;
using AutoMapper;
using System.Data;
using Domain.Models;
using Domain.Summary;
using Application.Helper;
using System.Collections.Generic;
using System.IO;

namespace Application.Services
{
    public class ClientesAppService : IClientesAppService
    {
        private readonly ILogger<IClientesAppService> _logger;
        private readonly IClientesRepository _appRepository;
        private readonly IMapper _mapper;

        public ClientesAppService(ILogger<IClientesAppService> logger, 
            IClientesRepository appRepository, 
            IMapper mapper)
        {
            _logger = logger;
            _appRepository = appRepository;
            _mapper = mapper;
        }
        public async Task<ClientesPFReportSummary> GetClientesPF(ClientesPFFilter filter)
        {
            filter.CPF = ValidationText.ValidarTexto(filter.CPF, 11);
            filter.Nome = ValidationText.ValidarTexto(filter.Nome, 100);

            ClientesPFReportSummary result = new ClientesPFReportSummary();
            result.Clientes = new List<ClientesPF>();

            var entity = await _appRepository.GetClientesPF(filter);

            if (entity != null && entity.Count > 0)
            {
                foreach (var item in entity)
                {
                    result.Clientes.Add(item);
                }
                result.QtdeLinhas = entity.Count;
            }

            return result;
        }
        public async Task<ClientesPJReportSummary> GetClientesPJ(ClientesPJFilter filter)
        {
            filter.CNPJ = ValidationText.ValidarTexto(filter.CNPJ, 14);
            filter.RazaoSocial = ValidationText.ValidarTexto(filter.RazaoSocial, 100);
            filter.NomeFantasia = ValidationText.ValidarTexto(filter.NomeFantasia, 100);

            ClientesPJReportSummary result = new ClientesPJReportSummary();
            result.Clientes = new List<ClientesPJ>();

            var entity = await _appRepository.GetClientesPJ(filter);

            if (entity != null && entity.Count > 0)
            {
                foreach (var item in entity)
                {
                    result.Clientes.Add(item);
                }
                result.QtdeLinhas = entity.Count;
            }

            return result;
        }
        public async Task<DataTable> GetClientesPFReports(ClientesPFFilter filter)
        {
            filter.CPF = ValidationText.ValidarTexto(filter.CPF, 11);
            filter.Nome = ValidationText.ValidarTexto(filter.Nome, 100);
            var result = await _appRepository.GetClientesPF(filter);

            DataTable data = new DataTable();
            data.TableName = "Relatório de Clientes Pessoa Física";
            data.Columns.Add("Id Cliente", typeof(int));
            data.Columns.Add("CPF", typeof(string));
            data.Columns.Add("Nome", typeof(string));
            data.Columns.Add("Sexo", typeof(string));
            data.Columns.Add("Data Nascimento", typeof(string));
            data.Columns.Add("RG", typeof(string));
            data.Columns.Add("Endereco", typeof(string));
            data.Columns.Add("Telefone", typeof(string));
            data.Columns.Add("E-mail", typeof(string));
            data.Columns.Add("Data de Atualização", typeof(string));

            string sexo = "";

            if (result != null && result.Count > 0)
            {
                foreach(var item in result)
                {
                    sexo = "Não Informado";
                    if (!string.IsNullOrEmpty(item.Sexo))
                    {
                        if (item.Sexo.ToUpper().Substring(0, 1) == "M")
                        {
                            sexo = "Masculino";
                        }
                        if (item.Sexo.ToUpper().Substring(0, 1) == "F")
                        {
                            sexo = "Feminino";
                        }
                        if (item.Sexo.ToUpper().Substring(0, 1) == "O")
                        {
                            sexo = "Outros";
                        }
                    }
                    data.Rows.Add(item.IdClientesPF, item.CPF, item.Nome, sexo, item.DataNascimento.ToString("dd/MM/yyyy"), item.RG, item.Endereco, item.Telefone, item.Email, item.DataAtualizacao.ToString("dd/MM/yyyy"));
                }
            }

            return data;
        }
        public async Task<DataTable> GetClientesPJReports(ClientesPJFilter filter)
        {
            filter.CNPJ = ValidationText.ValidarTexto(filter.CNPJ, 14);
            filter.RazaoSocial = ValidationText.ValidarTexto(filter.RazaoSocial, 100);
            filter.NomeFantasia = ValidationText.ValidarTexto(filter.NomeFantasia, 100);
            var result = await _appRepository.GetClientesPJ(filter);

            DataTable data = new DataTable();
            data.TableName = "Relatório de Clientes Pessoa Jurídica";
            data.Columns.Add("Id Cliente", typeof(int));
            data.Columns.Add("CNPJ", typeof(string));
            data.Columns.Add("Razão Social", typeof(string));
            data.Columns.Add("Nome Fantasia", typeof(string));
            data.Columns.Add("Endereco", typeof(string));
            data.Columns.Add("Telefone", typeof(string));
            data.Columns.Add("E-mail", typeof(string));
            data.Columns.Add("Data de Atualização", typeof(string));

            if (result != null && result.Count > 0)
            {
                foreach (var item in result)
                {
                    data.Rows.Add(item.IdClientesPJ, item.CNPJ, item.RazaoSocial,item.NomeFantasia, item.Endereco, item.Telefone, item.Email, item.DataAtualizacao.ToString("dd/MM/yyyy"));
                }
            }

            return data;
        }
        public async Task<bool> AddClientesPF(ClientesPFInsert dados)
        {
            try
            {
                ClientesPF clientes = new ClientesPF();
                clientes.IdClientesPF = 0;
                clientes.CPF = dados.CPF;
                clientes.Nome = dados.Nome;
                if (!string.IsNullOrEmpty(dados.Sexo))
                {
                    if ((dados.Sexo.ToUpper().Substring(0,1) == "M") || (dados.Sexo.ToUpper().Substring(0, 1) == "F") || (dados.Sexo.ToUpper().Substring(0, 1) == "O"))
                    {
                        clientes.Sexo = dados.Sexo.ToUpper().Substring(0, 1);
                    }
                }
                if (dados.DataNascimento.Year >= 1901)
                {
                    clientes.DataNascimento = dados.DataNascimento;
                }
                clientes.RG = dados.RG;
                clientes.Endereco = dados.Endereco;
                clientes.Telefone = dados.Telefone;
                clientes.Email = dados.Email;
                clientes.DataAtualizacao = DateTime.Now;
                    
                ClientesPFFilter filter = new ClientesPFFilter();
                filter.CPF = dados.CPF;
                var entity = await _appRepository.GetClientesPF(filter);

                if (entity != null && entity.Count > 0)
                {
                    foreach (var item in entity)
                    {
                        clientes.IdClientesPF = item.IdClientesPF;
                        if (string.IsNullOrEmpty(dados.Nome))
                        {
                            clientes.Nome = item.Nome;
                        }
                        if (string.IsNullOrEmpty(dados.Sexo))
                        {
                            clientes.Sexo = item.Sexo;
                        }
                        if (dados.DataNascimento.Year <= 1900)
                        {
                            clientes.DataNascimento = item.DataNascimento;
                        }
                        if (string.IsNullOrEmpty(dados.RG))
                        {
                            clientes.RG = item.RG;
                        }
                        if (string.IsNullOrEmpty(dados.Endereco))
                        {
                            clientes.Endereco = item.Endereco;
                        }
                        if (string.IsNullOrEmpty(dados.Telefone))
                        {
                            clientes.Telefone = item.Telefone;
                        }
                        if (string.IsNullOrEmpty(dados.Email))
                        {
                            clientes.Email = item.Email;
                        }
                    }
                }

                bool result = false;

                if (clientes.IdClientesPF == 0)
                {
                    result = await _appRepository.AddClientesPFAsync(clientes);
                }
                else
                {
                    result = await _appRepository.UpdateClientesPFAsync(clientes);
                }

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($" Erro ao incluir Clientes Pessoa Física : {ex.Message}");
                return false;
            }
        }
        public async Task<bool> DeleteClientesPF(ClientesPFDelete dados)
        {
            try
            {
                var result = await _appRepository.DeleteClientesPFAsync(dados.IdClientesPF);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($" Erro ao excluir Cliente Pessoa Física : {ex.Message}");
                return false;
            }
        }
        public async Task<bool> AddClientesPJ(ClientesPJInsert dados)
        {
            try
            {
                ClientesPJ clientes = new ClientesPJ();
                clientes.IdClientesPJ = 0;
                clientes.CNPJ = dados.CNPJ;
                clientes.RazaoSocial = dados.RazaoSocial;
                clientes.NomeFantasia = dados.NomeFantasia;
                clientes.Endereco = dados.Endereco;
                clientes.Telefone = dados.Telefone;
                clientes.Email = dados.Email;
                clientes.DataAtualizacao = DateTime.Now;

                ClientesPJFilter filter = new ClientesPJFilter();
                filter.CNPJ = dados.CNPJ;
                var entity = await _appRepository.GetClientesPJ(filter);

                if (entity != null && entity.Count > 0)
                {
                    foreach (var item in entity)
                    {
                        clientes.IdClientesPJ = item.IdClientesPJ;
                        if (string.IsNullOrEmpty(dados.RazaoSocial))
                        {
                            clientes.RazaoSocial = item.RazaoSocial;
                        }
                        if (string.IsNullOrEmpty(dados.NomeFantasia))
                        {
                            clientes.NomeFantasia = item.NomeFantasia;
                        }
                        if (string.IsNullOrEmpty(dados.Endereco))
                        {
                            clientes.Endereco = item.Endereco;
                        }
                        if (string.IsNullOrEmpty(dados.Telefone))
                        {
                            clientes.Telefone = item.Telefone;
                        }
                        if (string.IsNullOrEmpty(dados.Email))
                        {
                            clientes.Email = item.Email;
                        }
                    }
                }

                bool result = false;

                if (clientes.IdClientesPJ == 0)
                {
                    result = await _appRepository.AddClientesPJAsync(clientes);
                }
                else
                {
                    result = await _appRepository.UpdateClientesPJAsync(clientes);
                }

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($" Erro ao incluir Clientes Pessoa Jurídica : {ex.Message}");
                return false;
            }
        }
        public async Task<bool> DeleteClientesPJ(ClientesPJDelete dados)
        {
            try
            {
                var result = await _appRepository.DeleteClientesPJAsync(dados.IdClientesPJ);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($" Erro ao excluir Cliente Pessoa Jurídica : {ex.Message}");
                return false;
            }
        }
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
