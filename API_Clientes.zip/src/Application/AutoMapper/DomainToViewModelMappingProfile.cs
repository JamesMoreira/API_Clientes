﻿using AutoMapper;
using Domain.Models;

namespace Application.AutoMapper
{
    public class DomainToViewModelMappingProfile : Profile
    {
        public DomainToViewModelMappingProfile()
        {
            CreateMap<ClientesPF, ClientesPF>()
                .ForMember(dest => dest.IdClientesPF,
                opt => opt.MapFrom(src => src.IdClientesPF));

            CreateMap<ClientesPJ, ClientesPJ>()
                .ForMember(dest => dest.IdClientesPJ,
                opt => opt.MapFrom(src => src.IdClientesPJ));
        }
    }
}
