﻿using AutoMapper;
using Domain.Models;

namespace Application.AutoMapper
{
    public class ViewModelToDomainMappingProfile : Profile
    {
        public ViewModelToDomainMappingProfile()
        {
            CreateMap<ClientesPF, ClientesPF>()
                .ConstructUsing(c => new ClientesPF());
        }
    }
}
