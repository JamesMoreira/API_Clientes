﻿using System;
using System.Data;
using System.Threading.Tasks;
using Application.ViewModels;
using Domain.Filter;
using Domain.Summary;

namespace Application.Interfaces
{
    public interface IClientesAppService : IDisposable
    {
        public Task<ClientesPFReportSummary> GetClientesPF(ClientesPFFilter filter);
        public Task<ClientesPJReportSummary> GetClientesPJ(ClientesPJFilter filter);
        public Task<DataTable> GetClientesPFReports(ClientesPFFilter filter);
        public Task<DataTable> GetClientesPJReports(ClientesPJFilter filter);
        public Task<bool> AddClientesPF(ClientesPFInsert dados);
        public Task<bool> AddClientesPJ(ClientesPJInsert dados);
        public Task<bool> DeleteClientesPF(ClientesPFDelete dados);
        public Task<bool> DeleteClientesPJ(ClientesPJDelete dados);
    }
}
