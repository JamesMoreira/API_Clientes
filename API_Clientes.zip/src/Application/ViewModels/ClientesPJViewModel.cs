﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Application.ViewModels
{
    public class ClientesPJInsert
    {
        [Required(ErrorMessage = "CNPJ é obrigatório!")]
        public string CNPJ { get; set; }
        [Required(ErrorMessage = "Razão Social do cliente é obrigatória!")]
        public string RazaoSocial { get; set; }
        public string NomeFantasia { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }
        public string Email { get; set; }
    }
    public class ClientesPJDelete
    {
        [Required(ErrorMessage = "Id do Cliente Pessoa Jurídica precisa ser informado!")]
        public int IdClientesPJ { get; set; }
    }
}
