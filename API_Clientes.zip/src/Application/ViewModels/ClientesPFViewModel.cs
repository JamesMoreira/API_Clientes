﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Application.ViewModels
{
    public class ClientesPFInsert
    {
        [Required(ErrorMessage = "CPF é obrigatório!")]
        public string CPF { get; set; }
        [Required(ErrorMessage = "Nome do cliente é obrigatório!")]
        public string Nome { get; set; }
        public string Sexo { get; set; }
        public DateTime DataNascimento { get; set; }
        public string RG { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }
        public string Email { get; set; }
    }
    public class ClientesPFDelete
    {
        [Required(ErrorMessage = "Id do Cliente Pessoa Física precisa ser informado!")]
        public int IdClientesPF { get; set; }
    }
}
