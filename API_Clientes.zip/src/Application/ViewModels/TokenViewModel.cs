﻿using System;

namespace Application.ViewModels
{
    public class TokenViewModel
    {
        public string? Token { get; set; }
        public DateTime ValidTo { get; set; }
    }
}
